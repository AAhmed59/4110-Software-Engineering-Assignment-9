#Revision 1 START 3/22/22
##Begin Ashiq Ahmed here 3/22/22

#Import math to include pi
import math

#Define sphere_volume function to calculate the volume
def sphere_volume(radius):
    volume = (4/3)*math.pi*(radius**3)
    return volume

#Ask the user for the radius of the sphere and then calc volume
#Also check to see if the user provided a valid number
r = input("Enter the radius of the sphere: ")
while (r.isnumeric() != True):
    r = input("Please provide a valid number for the radius: ")
v = sphere_volume(int(r))
print(f"The volume of a sphere with radius {r} is {v}.")

#Revision 1 FINAL 3/22/22
##End Ashiq Ahmed here
#HALF-LIFE/Ron Bass/John Richards Sr./After-Burner Elite
